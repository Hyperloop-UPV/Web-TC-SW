
import './App.css'
import { useEffect, useState } from 'react'
import PokemonInfo from './PokemonInfo';


function App() {

  // List of pokemons
  const [pokemon, setPokemons] = useState([]);


  useEffect(() => {

    // Gets all the pokemons
    const fetchPokemons = async () => {
      try {
        // Fetch  limit means the number of pokemons that you would like to make
        const response = await fetch("https://pokeapi.co/api/v2/pokemon?limit=9");

        if (!response.ok) {
          throw new Error("Not able to fetch Pokemons");
        }

        // Update pokemons
        const fetchedPokemons = await response.json();

        setPokemons(fetchedPokemons.results)
      }
      catch (e) {

        console.error("ERROR");
      }
    }

    fetchPokemons();

  }, []);

  return <div className='app'>
    {/* Render each pokemon */}
    {pokemon.map(x => <PokemonInfo key={x.name} infoData={x} />)}

  </div>

}

export default App
