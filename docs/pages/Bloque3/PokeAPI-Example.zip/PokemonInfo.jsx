import { useEffect, useState } from "react";

function PokemonInfo({ infoData }) {

    // Pokemon data 
    const { name, url } = infoData;

    // Pokemon fetched data
    const [poke, setPoke] = useState({});


    useEffect(() => {

        // Function to fetch data ASYNC
        const fetchSinglePokemon = async () => {

            try {
                // Get data
                const res = await fetch(url);

                // It is ok?
                if (!res.ok) { throw new Error("No existe el pokemon") }

                // Update state
                const pokeInd = await res.json();
                setPoke(pokeInd)
            }

            catch (e) {

                console.error("eer");
            }

        }

        // Call the function
        fetchSinglePokemon();


    }, [])



    // Render pokemon data
    return <div className="pokemon">

        <h2>{name.toUpperCase()}</h2>

        <img height="75px" src={poke.sprites.front_default} />

    </div>

}


export default PokemonInfo;